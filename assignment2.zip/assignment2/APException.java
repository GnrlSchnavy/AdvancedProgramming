package assignment2;

class APException extends Exception {

	private static final long serialVersionUID = 1L;

	APException (String s) {
		super(s);
	}

}
