package assignment3;

/**
 * Created by user on 13/10/2014.
 */
public interface BinarySearchTreeInterface<E> {

	void insert();

	void delete();

	E max();

	E min();

	E successor();

}
