package assignment3;

public interface Data extends Clonable, Comparable<Object> {

    /*
       This interface defines a type on which an ordering contains been defined
       by compareTo() and from which copies can be made with clone().
    */

}